/// @ref core
/// @file glm/vec3.hpp

#pragma once

#include "detail/type_vec3.hpp"
